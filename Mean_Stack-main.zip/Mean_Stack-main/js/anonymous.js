var sayHello = function () {
  // defination
  console.log('Hello Function');
};

sayHello();
