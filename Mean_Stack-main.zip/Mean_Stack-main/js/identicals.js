var num1 = '55';
var num2 = 55;

// checks for value
if (num1 != num2) {
  console.log('Both are not same');
} else {
  console.log('Both are same');
}

// checks for value & data type
if (num1 !== num2) {
  console.log('Both are not identical');
} else {
  console.log('Both are identical');
}
