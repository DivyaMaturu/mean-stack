var cars = ['Audi Q3', 'BMW X1', 'Tata Harrier'];

// console.log(cars);

var flowers = new Array('Roses', 'Tulips', 'Lillies');

// console.log(flowers);

var mixedArray = ['John', 23, false, { name: 'Doe', age: 23, isLogged: true }];

// console.log(mixedArray);

for (var i = 0; i < flowers.length; i++) {
  console.log(flowers[i]);
}
