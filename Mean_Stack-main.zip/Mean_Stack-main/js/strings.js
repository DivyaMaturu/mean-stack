var firstName = 'aditya';

console.log('Length of the given string: ' + firstName.length);

console.log('Character at given index 2: ', firstName.charAt(2));

console.log('Index of a: ', firstName.indexOf('a'));
console.log('Last index of a: ', firstName.lastIndexOf('a'));

console.log('Substring :', firstName.substr(3, 2));

console.log('Upper case :', firstName.toUpperCase());
console.log('Lower case :', firstName.toLowerCase());
