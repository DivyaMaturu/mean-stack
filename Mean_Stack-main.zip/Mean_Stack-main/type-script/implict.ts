// explicit
let myName: string = 'Sasidhar';

// implicit
let firstName = 'Kola';
